# zabbix/

| File | Ghi chú |
|---|---|
| `esxi_host_exporter_zbx60.yaml` | Template Zabbix **6.0** — import vào Zabbix |
| `make_template.py` | Sinh lại file YAML (`python zabbix/make_template.py`); sửa template ở đây, không sửa tay YAML |

Tên item / trigger / LLD trong template bằng tiếng Anh (Title Case); hướng dẫn này giữ tiếng Việt.

Template đọc `/metrics` của `esxi_host_exporter.py` (không gọi vCenter trực tiếp), nên exporter phải đang chạy.

## Cài đặt

1. **Configuration → Templates → Import** (Zabbix 6.0) → chọn `esxi_host_exporter_zbx60.yaml` → Import.
2. Tạo host Zabbix đại diện cho máy chạy exporter (ví dụ `esxi-exporter-pool18`), interface Agent = IP máy exporter
   (không cần cài agent), gắn template **ESXi & vSAN Command Center**.
3. Port khác 9811 (mỗi instance / pool 1 port) → sửa macro `{$ESXI.EXPORTER.URL}` trên host, ví dụ
   `http://{HOST.CONN}:9812/metrics`. Nhiều pool → mỗi pool 1 host Zabbix.
4. Server / proxy Zabbix phải gọi được `http://<IP-exporter>:<port>/metrics` (mở firewall).
5. Khoảng 1–2 phút sau, LLD tạo item cho từng host ESXi, vmnic, disk vSAN, disk group, vmk vSAN, cluster.

### 1 exporter có nhiều pool → mỗi pool 1 host Zabbix

Exporter chạy `CLUSTER='-'` sẽ trả về mọi cluster của vCenter, nên 1 host Zabbix sẽ gom tất cả các pool. Muốn xem riêng từng pool:

1. Tạo **mỗi pool 1 host Zabbix** (ví dụ `ESXi Pool18`, `ESXi Pool19`), cùng IP / port exporter, cùng gắn template.
2. Trên từng host, vào tab **Macros** và lọc theo 1 trong 2 cách (là regex):

| Macro | Mặc định | Ví dụ |
|---|---|---|
| `{$ESXI.CLUSTER.MATCHES}` | `.*` (tất cả) | `^Pool18$`: chỉ lấy cluster Pool18 |
| `{$ESXI.CLUSTER.NOT_MATCHES}` | `CHANGE_IF_NEEDED` | `^Pool19$`: bỏ cluster Pool19 |
| `{$ESXI.HOST.MATCHES}` | `.*` | `^10\.0\.0\.2[1-5]$`: chỉ lấy host .21 → .25 |
| `{$ESXI.HOST.NOT_MATCHES}` | `CHANGE_IF_NEEDED` | |

3. LLD chỉ tạo item / trigger / đồ thị cho các object khớp bộ lọc, nên dashboard của host đó chỉ hiện đúng pool đó.
   Object đã tạo trước đó mà không còn khớp thì sẽ bị xoá sau `lifetime` 7 ngày; muốn xoá ngay thì xoá trong *Discovered items*.

Tên item / đồ thị có dạng `[cluster / host]` để nhìn biết luôn host thuộc cluster nào.
Các item `Exporter: ...` có trên mọi host Zabbix, nên khi exporter tắt, mỗi pool sẽ báo 1 cảnh báo.

## Cách hoạt động

- Item `Exporter: /metrics` (HTTP agent, 1 phút) lấy toàn bộ metric và không lưu history. Các item khác là Dependent,
  tách bằng preprocessing *Prometheus pattern*. Metric không có (ví dụ host mất kết nối nên không có CPU) thì bỏ qua giá trị, item không bị lỗi.
- Disk health, vSAN network latency, phần cứng: exporter chỉ lấy mỗi 5 phút (`ESXI_SLOW_INTERVAL`).

## Tag (lọc Items / Latest data / Problems)

| Tag | Giá trị | Ví dụ lọc |
|---|---|---|
| `scope` | `host` · `vmnic` · `disk` · `diskgroup` · `vmk` · `cluster` · `summary` · `exporter` | chỉ xem disk: `scope = disk` |
| `cluster` | tên cluster | `cluster = POOL18` |
| `host` | IP / tên host ESXi | `host = 10.0.0.21` |
| `nic` / `disk` / `diskgroup` / `vmk` / `direction` | tên object | `disk contains eui.3433` |
| `component` | `host` · `cpu` · `memory` · `vsan` · `vsan-disk` · `network` · `summary` · `exporter` | nhóm chỉ số |
| `level` (chỉ trigger) | `2` · `3` | chỉ Mức 2: `level = 2` |

Trigger mang đủ tag của item (`scope`, `cluster`, `host`, `component`...), nên ở **Monitoring → Problems** lọc được theo
pool / host / disk. Ví dụ: `cluster = POOL18` và `level = 2`.

## Trigger (Mức 2 = severity High, Mức 3 = severity Warning, tag `level` = 2 / 3)

| Chỉ số | Trigger | Mức |
|---|---|---|
| Host Status / ESXi service | Host mất kết nối vCenter · Phần cứng host lỗi | 2 |
| NIC | vmnic DOWN | 2 |
| CPU | `min(5m)` > `{$ESXI.CPU.HIGH}`=60 / > `{$ESXI.CPU.WARN}`=40 | 2 / 3 |
| RAM | `min(5m)` > `{$ESXI.RAM.HIGH}`=90 / > `{$ESXI.RAM.WARN}`=80 | 2 / 3 |
| Disk Group / Disk Health | Disk RED · DiskGroup RED · % disk healthy < `{$ESXI.DISKPCT.HIGH}`=70 | 2 |
| | % disk healthy < `{$ESXI.DISKPCT.WARN}`=80 · Disk YELLOW | 3 |
| Disk latency (tạm) | write `min(10m)` > `{$ESXI.LAT.HIGH}`=30ms / > `{$ESXI.LAT.WARN}`=15ms | 2 / 3 |
| vSAN network latency | > `{$ESXI.NETLAT.HIGH}`=1ms / > `{$ESXI.NETLAT.WARN}`=0,5ms | 2 / 3 |
| vSAN congestion / Resync | congestion > `{$ESXI.CONG.HIGH}`=60 · resync > 0 trong 2 phút | 2 |
| Host maintenance | Host vào chế độ bảo trì | 3 |
| (khác) | Drop vmk vSAN `min(5m)` > `{$ESXI.VMKDROP.WARN}`=0,1% · exporter không đọc được / mất dữ liệu vCenter | 3 |

Trigger Mức 3 **phụ thuộc** trigger Mức 2 cùng chỉ số: khi Mức 2 bắn thì Mức 3 tự ẩn, không báo 2 lần.
Đổi ngưỡng: sửa macro trên template (áp dụng tất cả) hoặc trên từng host Zabbix.

### Màu theo mức

Màu cảnh báo theo **severity**, là cài đặt chung của Zabbix (template không đổi được):
**Administration → General → Trigger displaying options**.
Mặc định High (Mức 2) = cam đỏ `E97659`, Warning (Mức 3) = vàng `FFC859`.
Muốn Mức 2 đỏ hẳn: đặt High = `E45959`.
Đồ thị trong template tự vẽ đường ngưỡng của trigger theo đúng màu severity này.

## Dashboard

Template có sẵn dashboard **ESXi & vSAN Command Center**. Mở: **Monitoring → Hosts** → cột *Dashboards* của host exporter.
Mỗi trang chia 3 tầng: **ô số liệu tổng của pool** → **đồ thị tổng** → **đồ thị từng host / vmnic / cluster**.

| Trang | Ô số liệu tổng | Đồ thị tổng | Từng object |
|---|---|---|---|
| Hosts | ESXi Hosts · Disconnected · Hardware Error · In Maintenance · CPU Max · Memory Max · Running VMs · vCenter Collection | CPU & Memory (Max / Avg) · Problem Counts | CPU & Memory, vSAN Latency theo host |
| vSAN | Failed Disks · Degraded Disks · Lowest Healthy Disks · Write Latency Max · Network Latency Max · Resync Objects | vSAN Latency (Max) · vSAN Resync | Healthy vSAN Disks theo host, Resync theo cluster |
| Network | vmnic Uplinks · vmnic Down · vSAN vmk Drop Max · Congestion Max · Total Sent · Total Received | Total vmnic Traffic | vmnic Traffic theo host |

Số tổng lấy từ các item `Summary: ...` (đếm / cộng / max / min / avg ngay trên `/metrics`) và lọc theo cùng macro
`{$ESXI.CLUSTER.*}` / `{$ESXI.HOST.*}` như LLD, nên mỗi host Zabbix (pool) chỉ tính pool của nó.

Danh sách cảnh báo (Problems): thêm widget *Problems* vào dashboard chung (Monitoring → Dashboard),
lọc host group hoặc tag `target: esxi` (dashboard của template không có widget Problems).
