# Copyright (c) 2006-2024 Broadcom. All Rights Reserved.
# Broadcom Confidential. The term "Broadcom" refers to Broadcom Inc.
# and/or its subsidiaries.

# ******* WARNING - AUTO GENERATED CODE - DO NOT EDIT *******

from pyVmomi.vmodl import DynamicData

from pyVmomi.pbm.capability import CapabilityMetadata

class CapabilityObjectMetadataPerCategory(DynamicData):
   subCategory: str
   capabilityMetadata: list[CapabilityMetadata] = []
