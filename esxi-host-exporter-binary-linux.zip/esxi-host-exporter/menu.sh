#!/usr/bin/env bash
# Copyright (c) 2026 FIX NHANH. All rights reserved. Proprietary.
exec /opt/esxi-host-exporter/esxi-host-exporter --run-menu "$@"
